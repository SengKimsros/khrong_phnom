
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- ===== Page-Container ===== -->
    <div class="container-fluid">
        <div class="page-wrapper" style="min-height: 525px;">
            <div class="container-fluid">
                <h1>Project</h1>
            </div>
        </div>
    </div>
    <!-- ===== Page-Container-End ===== -->
    <footer class="footer t-a-c">
        © 2017 Cubic Admin
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mr Sey\khrong_phnom_final\resources\views/admin/project/project.blade.php ENDPATH**/ ?>