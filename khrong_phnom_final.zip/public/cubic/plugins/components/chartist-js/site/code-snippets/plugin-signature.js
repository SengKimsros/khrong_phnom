function myChartistPlugin(chart) {

}
